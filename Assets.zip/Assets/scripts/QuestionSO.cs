using UnityEngine;
[CreateAssetMenu(menuName ="Quiz Question", fileName = "New Question")]
public class QuestionSO : ScriptableObject
{
    [TextArea(2,6)]
    [SerializeField] string Question = "Enter new question text here";
    [SerializeField] public string[] answers = new string[4];
    [SerializeField] public int correctAnswerIndex;
    

    public string GetQuestion(){
        
        return Question;
    }

    public int GetCorrentIndex(){

        return correctAnswerIndex;
    }

    public string GetIndex(int index){
        
        return answers[index];
    }

    public string GetAnswer(int index)
    {
        return answers[index];
    }
}
