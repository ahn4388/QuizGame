using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class Quiz : MonoBehaviour
{
    [Header("Questions")]
    [SerializeField] TextMeshProUGUI questionText;
    [SerializeField] List<QuestionSO> questions; 
    List<QuestionSO> tempQuestions;   // 임시로 문제를 꺼내 쓸 리스트
    QuestionSO currentQuestion;

    [Header("Answers")]
    [SerializeField] GameObject[] answerButtons;
    int correntAnswerIndex;
    bool hasAnsweredEarly = false;

    [Header("Button Colors")]
    [SerializeField] Sprite defaultAnswerSprite;
    [SerializeField] Sprite correctAnswerSprite;

    [Header("Timer")]
    [SerializeField] Image timerImage;
    Timer timer;

    [Header("Scoring")]
    [SerializeField] TextMeshProUGUI scoreText;
    [SerializeField] ScoreKeeper scoreKeeper;

    [Header("ProgressBar")]
    [SerializeField] Slider progressBar;

    public bool isComplete;

    void Start()
    {
        // Timer, ScoreKeeper 찾기
        timer = FindAnyObjectByType<Timer>();
        scoreKeeper = FindAnyObjectByType<ScoreKeeper>();

        // questions 리스트 복제
        tempQuestions = new List<QuestionSO>(questions);

        // 슬라이더 설정 (0 ~ questions.Count)
        progressBar.minValue = 0;
        progressBar.maxValue = questions.Count;
        progressBar.value = 0; // ★0에서 시작

        // 첫 문제 로드 (슬라이더는 그대로 0 유지)
        GetNextQuestion();
    }

    void Update()
    {
        // 타이머 UI
        timerImage.fillAmount = timer.fillFraction;

        // 타이머가 "새 문제 로드" 신호를 보냈다면
        if (timer.loadNextQuestion)
        {
            hasAnsweredEarly = false;
            GetNextQuestion();
            timer.loadNextQuestion = false;
        }
        // 아직 답을 선택 안 했는데 풀이 시간이 끝난 경우 → 자동 오답 처리
        else if (!hasAnsweredEarly && !timer.isAnsweringQuestion)
        {
            DisplayAnswer(-1);
            SetButtonState(false);

            // 문제 완료 시점에 슬라이더/점수 증가
            CompleteQuestion();
        }
    }

    // 사용자가 정답 버튼을 골랐을 때
    public void OnAnswerSelected(int index)
    {
        hasAnsweredEarly = true;
        DisplayAnswer(index);
        SetButtonState(false);

        // 문제 완료 시점에 슬라이더/점수 증가
        CompleteQuestion();

        // 타이머 종료 → 정답 확인 단계로
        timer.CancelTimer();

        // 점수 표시
        scoreText.text = $"score: {scoreKeeper.CalculateScore()}%";
    }

    // 실제 문제 1개를 마무리했을 때(정답 선택 or 시간초과) 호출
    void CompleteQuestion()
    {
        // 슬라이더 & 문제 Seen 카운트 증가
        progressBar.value++;
        scoreKeeper.IncrementQuestionSeen();

        // 모든 문제를 다 풀었는지 확인
        if (progressBar.value == progressBar.maxValue)
        {
            isComplete = true;
            Debug.Log("모든 문제를 풀었습니다!");
        }
    }

    void GetNextQuestion()
    {
        // 다음 문제가 남아 있다면 로드
        if (tempQuestions.Count > 0)
        {
            // 초기화
            SetButtonState(true);
            SetDefaultButtonSprite();

            // 랜덤으로 문제 선택
            int randIndex = Random.Range(0, tempQuestions.Count);
            currentQuestion = tempQuestions[randIndex];
            tempQuestions.RemoveAt(randIndex);

            // UI 표시
            DisplayQuestion();
        }
        else
        {
            isComplete = true;
            Debug.Log("tempQuestions가 비었습니다. 모든 문제 출제 완료.");
        }
    }

    void DisplayQuestion()
    {
        questionText.text = currentQuestion.GetQuestion();
        for (int i = 0; i < answerButtons.Length; i++)
        {
            TextMeshProUGUI btnText = answerButtons[i].GetComponentInChildren<TextMeshProUGUI>();
            btnText.text = currentQuestion.GetAnswer(i);
        }
    }

    void DisplayAnswer(int index)
    {
        if (index == currentQuestion.GetCorrentIndex())
        {
            questionText.text = "Correct!";
            Image buttonImage = answerButtons[index].GetComponent<Image>();
            buttonImage.sprite = correctAnswerSprite;
            scoreKeeper.IncrementCorrectAnswers();
        }
        else
        {
            int correctIndex = currentQuestion.GetCorrentIndex();
            string correctAnswer = currentQuestion.GetAnswer(correctIndex);
            questionText.text = $"Incorrect!\nCorrect Answer: {correctAnswer}";

            Image buttonImage = answerButtons[correctIndex].GetComponent<Image>();
            buttonImage.sprite = correctAnswerSprite;
        }
    }

    void SetButtonState(bool state)
    {
        foreach (GameObject buttonObj in answerButtons)
        {
            var btn = buttonObj.GetComponent<Button>();
            btn.interactable = state;
        }
    }

    void SetDefaultButtonSprite()
    {
        foreach (GameObject buttonObj in answerButtons)
        {
            var btnImage = buttonObj.GetComponent<Image>();
            btnImage.sprite = defaultAnswerSprite;
        }
    }
}
