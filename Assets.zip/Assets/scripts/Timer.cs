using UnityEngine;

public class Timer : MonoBehaviour
{
    [SerializeField] float timeToCompleteQuestion = 30f;   // 문제 풀이 시간
    [SerializeField] float timeToShowCorrectAnswer = 10f; // 정답 확인 시간

    public bool loadNextQuestion;     // 다음 문제 로드를 Quiz에 신호
    public float fillFraction;        // Slider 등 UI 표시용
    public bool isAnsweringQuestion;  // true = 문제 풀이, false = 정답 확인
    
    float timerValue;                 // 내부 카운트다운용

    void Start()
    {
        // ★ 처음엔 문제 풀이 모드 + 30초
        isAnsweringQuestion = true;
        timerValue = timeToCompleteQuestion;
        loadNextQuestion = false;  // 시작 시에는 “다음 문제 로딩” 신호 안 보냄
    }

    void Update()
    {
        UpdateTimer();
    }

    void UpdateTimer()
    {
        timerValue -= Time.deltaTime;

        if (isAnsweringQuestion)
        {
            // 문제 풀이 시간(30초) 진행
            if (timerValue > 0)
            {
                fillFraction = timerValue / timeToCompleteQuestion;
            }
            else
            {
                // 문제 풀이가 끝나면 정답 확인 모드로 전환
                isAnsweringQuestion = false;
                timerValue = timeToShowCorrectAnswer;
            }
        }
        else
        {
            // 정답 확인 시간(10초) 진행
            if (timerValue > 0)
            {
                fillFraction = timerValue / timeToShowCorrectAnswer;
            }
            else
            {
                // 정답 확인이 끝나면 다시 문제 풀이 모드 + 새 문제 로딩 신호
                isAnsweringQuestion = true;
                timerValue = timeToCompleteQuestion;
                loadNextQuestion = true; // Quiz가 다음 문제 로드
            }
        }
    }

    // 사용자가 정답을 미리 선택하면 시간을 0으로 만들어 즉시 정답 확인 단계로
    public void CancelTimer()
    {
        timerValue = 0;
    }
}
